import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler

# Load data
covid_data = pd.read_csv('data/complete.csv')
covid_data = covid_data[['Name of State / UT', 'Death', 'Cured/Discharged/Migrated', 'Latitude', 'Longitude']]
covid_data[['Deaths', 'Cured']] = covid_data[['Death', 'Cured/Discharged/Migrated']].apply(pd.to_numeric, errors='coerce')
covid_data.fillna(0, inplace=True)

# Create GeoDataFrame
geometry = gpd.points_from_xy(covid_data['Longitude'], covid_data['Latitude'])
gdf = gpd.GeoDataFrame(covid_data, geometry=geometry)

# Load shapefile
india_map = gpd.read_file('data/india_st.shp')
gdf.crs = india_map.crs

# Apply DBSCAN clustering
X = gdf[['Latitude', 'Longitude']]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
dbscan = DBSCAN(eps=0.5, min_samples=5)
gdf['Cluster'] = dbscan.fit_predict(X_scaled)

# Plot
fig, ax = plt.subplots(figsize=(12, 8))
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)

india_map.plot(ax=ax, color='lightgrey', edgecolor='black')
gdf.plot(ax=ax, marker='o', column='Cluster', cmap='viridis', markersize=20, alpha=0.7, legend=True, cax=cax)

plt.title('Spatial Clustering of COVID-19 Data in India')
plt.savefig('screenshots/spatial_clusters.png')
plt.show()

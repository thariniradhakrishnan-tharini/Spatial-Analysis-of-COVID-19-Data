import pandas as pd

# Load the dataset
covid_data = pd.read_csv('data/complete.csv')  # Ensure file name matches in data/

# Display first and last few rows
print(covid_data.head())
print(covid_data.tail())

# Summary statistics for Death column
df = covid_data['Death'].describe()
print("Summary Statistics for Deaths:")
print(df)

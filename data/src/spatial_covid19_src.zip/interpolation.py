import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable
from scipy.interpolate import griddata
import numpy as np

# Load data
covid_data = pd.read_csv('data/complete.csv')
covid_data = covid_data[['Name of State / UT', 'Death', 'Cured/Discharged/Migrated', 'Latitude', 'Longitude']]
covid_data[['Deaths', 'Cured']] = covid_data[['Death', 'Cured/Discharged/Migrated']].apply(pd.to_numeric, errors='coerce')
covid_data.fillna(0, inplace=True)

# Create GeoDataFrame
geometry = gpd.points_from_xy(covid_data['Longitude'], covid_data['Latitude'])
gdf = gpd.GeoDataFrame(covid_data, geometry=geometry)
india_map = gpd.read_file('data/india_st.shp')
gdf.crs = india_map.crs

# Interpolation for 'Cured'
interpolation_variable = 'Cured'
X = gdf[['Longitude', 'Latitude']].values
y = gdf[interpolation_variable].values
grid_x, grid_y = np.meshgrid(
    np.linspace(gdf['Longitude'].min(), gdf['Longitude'].max(), 100),
    np.linspace(gdf['Latitude'].min(), gdf['Latitude'].max(), 100)
)
grid_z = griddata((X[:, 0], X[:, 1]), y, (grid_x, grid_y), method='linear')

# Plot
fig, ax = plt.subplots(figsize=(12, 8))
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)

india_map.plot(ax=ax, color='lightgrey', edgecolor='black')
gdf.plot(ax=ax, marker='o', column=interpolation_variable, cmap='viridis', markersize=20, alpha=0.7, legend=True, cax=cax)
plt.imshow(grid_z, extent=(grid_x.min(), grid_x.max(), grid_y.min(), grid_y.max()), origin='lower', cmap='viridis', alpha=0.5)
plt.colorbar(cax=cax, label=f'{interpolation_variable} (Interpolated)')

plt.title('Spatial Interpolation of Cured Cases in India')
plt.savefig('screenshots/interpolation_map.png')
plt.show()

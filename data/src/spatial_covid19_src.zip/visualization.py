import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
covid_data = pd.read_csv('data/complete.csv')

# Bar Plot
columns_of_interest = ['Total Confirmed cases', 'Death', 'Cured/Discharged/Migrated', 'New cases', 'New deaths', 'New recovered']
for column in columns_of_interest:
    covid_data[column] = pd.to_numeric(covid_data[column], errors='coerce')
cases_data = covid_data[columns_of_interest].sum()

plt.figure(figsize=(10, 5))
cases_data.plot(kind='bar', color=['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#c2c2f0', '#66b3ff'])
plt.title('Distribution of COVID-19 Cases')
plt.xlabel('Categories')
plt.ylabel('Number of Cases')
plt.savefig('screenshots/bar_plot.png')
plt.show()

# Histograms
selected_columns = ['Total Confirmed cases', 'Death', 'New cases', 'New deaths', 'Cured/Discharged/Migrated']
covid_data[selected_columns] = covid_data[selected_columns].apply(pd.to_numeric, errors='coerce')
sns.set(style="white", font_scale=1.5)
plt.figure(figsize=(12, 12))
for column in selected_columns:
    sns.histplot(covid_data[column], kde=True, label=column, alpha=0.7, bins=150)
plt.legend()
plt.title('Distribution of COVID-19 Columns')
plt.show()
